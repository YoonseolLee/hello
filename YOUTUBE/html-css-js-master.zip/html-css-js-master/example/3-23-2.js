document.querySelectorAll('a');
