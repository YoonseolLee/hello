'            hello          '
'            hello          '.trim()
