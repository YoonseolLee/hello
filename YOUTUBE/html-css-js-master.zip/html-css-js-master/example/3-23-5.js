var alist = document.querySelectorAll('a');
var i = 0;
while(i < alist.length) {
    alist[i].style.color = 'powderblue';
    console.log(alist[i]);
    i = i + 1;
}
