var coworkers = ['egoing', 'leezche'];
coworkers[0];
coworkers[1];
