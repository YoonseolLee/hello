'Hello World'.toUpperCase()
