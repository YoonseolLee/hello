'Hello world'.indexOf('O')
'Hello world'.indexOf('o')
