var alist = document.querySelectorAll('a');
var i = 0;
while(i < alist.length) {
    console.log(alist[i]);
    i = i + 1;
}
