var alist = document.querySelectorAll('a');
console.log(alist[0]);
console.log(alist[1]);
console.log(alist.length);
