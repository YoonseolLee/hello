'Hello world'.indexOf('world')
